import hdf5_getters
import os
import sys

dataRoot = sys.argv[1]

startLetter = "A"
if (len(sys.argv) == 3):
    startLetter = sys.argv[2]

def getValues(in_path, out_file):
    h5 = hdf5_getters.open_h5_file_read(in_path)
    longitude = str(hdf5_getters.get_artist_longitude(h5))
    if (longitude != "nan"):
        longitude = longitude + ","
        latitude = str(hdf5_getters.get_artist_latitude(h5)) + ","
        loudness = str(hdf5_getters.get_loudness(h5)) + ","
        danceability = str(hdf5_getters.get_danceability(h5)) + ","
        energy = str(hdf5_getters.get_energy(h5)) + ","
        tempo = str(hdf5_getters.get_tempo(h5)) + ","
        hotness = str(hdf5_getters.get_song_hotttnesss(h5)) + ","
        year = str(hdf5_getters.get_year(h5))
        if year == "0":
            year = "NULL"
        val = "INSERT INTO songs(longitude,latitude,loudness,danceability,energy,tempo,hotness,year) VALUES(" + longitude + latitude + loudness + danceability + energy + tempo + hotness + year + ")"
        val = val.replace("nan", "NULL")
        out_file.write(val + '\n')
    h5.close()

def parseOneLetter(letter_path, out_file):
    for root, dirs, filenames in os.walk(letter_path):
        for f in filenames:
            if f != ".DS_Store":
                path = root + "/" + f
                getValues(path, out_file)            

# get the first level dir names
rootLetters = []
for root, dirs, filenames in os.walk(dataRoot):
    rootLetters = dirs
    break

letterFound = False
for letter in rootLetters:
    if (letterFound or letter == startLetter):
        if (letter == startLetter):
            letterFound = True
        file = open(letter + ".txt", 'w')
        parseOneLetter(dataRoot + "/" + letter, file)
        file.close()